// Advanced Sweet & Realistic Female Voice Speech Engine for Patel CCTV Camera World
// Supports Gujarati (ગુજરાતી), Marathi (मराठी), Kannada (ಕನ್ನಡ), Hindi (हिन्दी), and English
import { Language } from '../types';

// Audio Context for soft welcoming entrance chime
let audioCtx: AudioContext | null = null;

const playGentleWelcomeChime = async () => {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    if (!audioCtx || audioCtx.state === 'closed') {
      audioCtx = new AudioContextClass();
    }
    if (audioCtx.state === 'suspended') {
      await audioCtx.resume();
    }

    const now = audioCtx.currentTime;

    // Harmonic bell chime notes (523.25Hz C5 -> 659.25Hz E5 -> 783.99Hz G5)
    const notes = [523.25, 659.25, 783.99];
    notes.forEach((freq, index) => {
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + index * 0.12);

      gain.gain.setValueAtTime(0.001, now + index * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.12, now + index * 0.12 + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + index * 0.12 + 0.6);

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start(now + index * 0.12);
      osc.stop(now + index * 0.12 + 0.65);
    });
  } catch (e) {
    console.debug('Chime audio context skipped:', e);
  }
};

// Helper to find the best sweet female voice for a given language code
const getBestFemaleVoice = (voices: SpeechSynthesisVoice[], langCode: Language): SpeechSynthesisVoice | null => {
  if (!voices || voices.length === 0) return null;

  const femaleKeywords = [
    'female', 'woman', 'girl', 'swara', 'kalpana', 'neerja', 'priya',
    'kavya', 'lekha', 'veena', 'shruti', 'diti', 'heera', 'vani',
    'google हिन्दी', 'google hi', 'google gu', 'google mr', 'google kn',
    'google uk english female', 'google us english female', 'samantha',
    'karen', 'moira', 'victoria', 'zira', 'aria', 'jenny', 'natural', 'neural'
  ];

  const prefix = langCode.toLowerCase();

  // 1. Preferred target language female voice
  const matchingLangVoices = voices.filter(v => {
    const vLang = v.lang.toLowerCase();
    return vLang.startsWith(prefix) || 
      vLang.includes(`-${prefix}`) || 
      v.name.toLowerCase().includes(prefix);
  });

  const targetFemale = matchingLangVoices.find(v => 
    femaleKeywords.some(kw => v.name.toLowerCase().includes(kw))
  );
  if (targetFemale) return targetFemale;
  if (matchingLangVoices.length > 0) return matchingLangVoices[0];

  // 2. Indian language fallback (Hindi or Indian English)
  const indianVoices = voices.filter(v => 
    v.lang.toLowerCase().includes('in') || 
    v.lang.toLowerCase().startsWith('hi') ||
    v.name.toLowerCase().includes('india')
  );

  const indianFemale = indianVoices.find(v => 
    femaleKeywords.some(kw => v.name.toLowerCase().includes(kw))
  );
  if (indianFemale) return indianFemale;
  if (indianVoices.length > 0) return indianVoices[0];

  // 3. High-quality natural English female voice fallback
  const enFemale = voices.find(v => 
    v.lang.toLowerCase().startsWith('en') && 
    femaleKeywords.some(kw => v.name.toLowerCase().includes(kw))
  );
  if (enFemale) return enFemale;

  return voices[0] || null;
};

// Global state callback for listening to speech events
type SpeechStateListener = (isPlaying: boolean, currentLang: Language | null) => void;
const listeners: Set<SpeechStateListener> = new Set();

export const subscribeSpeechState = (listener: SpeechStateListener) => {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
};

const notifyState = (isPlaying: boolean, currentLang: Language | null) => {
  listeners.forEach(fn => fn(isPlaying, currentLang));
};

let isCurrentlySpeaking = false;

export const isSpeakingAudio = () => isCurrentlySpeaking;

export const stopWelcomeAudio = () => {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    isCurrentlySpeaking = false;
    notifyState(false, null);
  }
};

const WELCOME_MESSAGES: Record<Language, string> = {
  hi: 'पटेल सीसीटीवी कैमरा वर्ल्ड में आपका हार्दिक स्वागत है।',
  gu: 'પટેલ સીસીટીવી કેમેરા વર્લ્ડમાં આપનું હાર્દિક સ્વાગત છે.',
  mr: 'पटेल सीसीटीव्ही कॅमेरा वर्ल्डमध्ये आपले सहर्ष स्वागत आहे.',
  kn: 'ಪಟೇಲ್ ಸಿಸಿಟಿವಿ ಕ್ಯಾಮೆರಾ ವರ್ಲ್ಡ್‌ಗೆ ನಿಮಗೆ ಆತ್ಮೀಯ ಸ್ವಾಗತ.',
  en: 'Welcome to Patel CCTV Camera World.',
  ta: 'பட்டேல் CCTV கேமரா உலகிற்கு உங்களை அன்புடன் வரவேற்கிறோம்.',
  te: 'పటేల్ CCTV కెమెరా వరల్డ్‌కి మీకు స్వాగతం.',
  ml: 'പട്ടേൽ CCTV ക്യാമറ വേൾഡിലേക്ക് നിങ്ങൾക്ക് സ്വാഗതം.',
};

/**
 * Main Welcome Speech Function
 * Plays gentle chime, then speaks the welcome message in the selected language,
 * followed by English if the selected language is not English.
 */
export const speakWelcomeAudio = async (selectedLang: Language = 'hi') => {
  if (typeof window === 'undefined') return;

  try {
    if (!('speechSynthesis' in window)) {
      console.warn('Speech synthesis not supported on this browser.');
      return;
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();
    isCurrentlySpeaking = true;
    notifyState(true, selectedLang);

    // 1. Play soft entrance chime
    await playGentleWelcomeChime();

    const startSpeechChain = () => {
      const voices = window.speechSynthesis.getVoices();

      // Step 1: Native Language Welcome Message
      const nativeText = WELCOME_MESSAGES[selectedLang] || WELCOME_MESSAGES.hi;
      const nativeUtterance = new SpeechSynthesisUtterance(nativeText);
      
      const nativeVoice = getBestFemaleVoice(voices, selectedLang);
      if (nativeVoice) {
        nativeUtterance.voice = nativeVoice;
        nativeUtterance.lang = nativeVoice.lang || `${selectedLang}-IN`;
      } else {
        nativeUtterance.lang = `${selectedLang}-IN`;
      }

      // Sweet, gentle, natural human pitch and tempo
      nativeUtterance.rate = 0.88;
      nativeUtterance.pitch = 1.15;
      nativeUtterance.volume = 1.0;

      // Step 2: English Speech (If selected language is not already English)
      const englishText = 'Welcome to Patel CCTV Camera World.';
      const englishUtterance = new SpeechSynthesisUtterance(englishText);
      
      const englishVoice = getBestFemaleVoice(voices, 'en');
      if (englishVoice) {
        englishUtterance.voice = englishVoice;
        englishUtterance.lang = englishVoice.lang || 'en-IN';
      } else {
        englishUtterance.lang = 'en-IN';
      }

      englishUtterance.rate = 0.88;
      englishUtterance.pitch = 1.12;
      englishUtterance.volume = 1.0;

      if (selectedLang !== 'en') {
        nativeUtterance.onend = () => {
          if (!isCurrentlySpeaking) return;
          notifyState(true, 'en');
          setTimeout(() => {
            if (!isCurrentlySpeaking) return;
            try {
              window.speechSynthesis.speak(englishUtterance);
            } catch (e) {
              console.warn('English speech error:', e);
              isCurrentlySpeaking = false;
              notifyState(false, null);
            }
          }, 350);
        };

        nativeUtterance.onerror = () => {
          notifyState(true, 'en');
          try {
            window.speechSynthesis.speak(englishUtterance);
          } catch {
            isCurrentlySpeaking = false;
            notifyState(false, null);
          }
        };

        englishUtterance.onend = () => {
          isCurrentlySpeaking = false;
          notifyState(false, null);
        };

        englishUtterance.onerror = () => {
          isCurrentlySpeaking = false;
          notifyState(false, null);
        };
      } else {
        nativeUtterance.onend = () => {
          isCurrentlySpeaking = false;
          notifyState(false, null);
        };
        nativeUtterance.onerror = () => {
          isCurrentlySpeaking = false;
          notifyState(false, null);
        };
      }

      // Speak native welcome
      window.speechSynthesis.speak(nativeUtterance);
    };

    const availableVoices = window.speechSynthesis.getVoices();
    if (availableVoices && availableVoices.length > 0) {
      startSpeechChain();
    } else {
      window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.onvoiceschanged = null;
        startSpeechChain();
      };
      setTimeout(() => {
        if (isCurrentlySpeaking) {
          startSpeechChain();
        }
      }, 250);
    }
  } catch (err) {
    console.warn('Speech synthesis exception:', err);
    isCurrentlySpeaking = false;
    notifyState(false, null);
  }
};

/**
 * Security Warning Speech for Login
 * Speaks the anti-fraud notice verbatim in clear voice
 */
export const speakLoginSecurityWarningAudio = async (
  onStart?: () => void,
  onEnd?: () => void
): Promise<() => void> => {
  if (typeof window === 'undefined') return () => {};

  try {
    if (!('speechSynthesis' in window)) {
      console.warn('Speech synthesis not supported on this browser.');
      onEnd?.();
      return () => {};
    }

    window.speechSynthesis.cancel();
    isCurrentlySpeaking = true;
    notifyState(true, 'hi');

    await playGentleWelcomeChime();
    onStart?.();

    const warningHindiText = 
      "सावधानी नोट! कोई भी हमारे नाम का मिसयूज कर सकता है, तो कृपया नंबरों की जांच करके ही किसी का फोन या व्हाट्सएप पर मैसेज आए तो नंबरों की जांच करें उसके बाद ही उसके ऊपर भरोसा करें। " +
      "अगर यह नीचे दिया गया हुआ नंबर प्लस 91 74830 05197 के अलावा कोई दूसरा नंबर से आपको मैसेज करे, तो उससे पहले कंफर्म कर लीजिएगा कि कोई फ्रॉड तो नहीं है। " +
      "और अगर आपके साथ फ्रॉड हो तो नजदीकी पुलिस स्टेशन में रिपोर्ट दर्ज करें या फिर इस नंबर पर कॉल करें: 80009 51663। आपका धन्यवाद!";

    const warningUtterance = new SpeechSynthesisUtterance(warningHindiText);
    const voices = window.speechSynthesis.getVoices();
    const hindiVoice = getBestFemaleVoice(voices, 'hi');

    if (hindiVoice) {
      warningUtterance.voice = hindiVoice;
      warningUtterance.lang = hindiVoice.lang || 'hi-IN';
    } else {
      warningUtterance.lang = 'hi-IN';
    }

    warningUtterance.rate = 0.86;
    warningUtterance.pitch = 1.05;
    warningUtterance.volume = 1.0;

    warningUtterance.onend = () => {
      isCurrentlySpeaking = false;
      notifyState(false, null);
      onEnd?.();
    };

    warningUtterance.onerror = () => {
      isCurrentlySpeaking = false;
      notifyState(false, null);
      onEnd?.();
    };

    const startSpeak = () => {
      try {
        window.speechSynthesis.speak(warningUtterance);
      } catch (err) {
        console.warn('Failed to speak warning:', err);
        onEnd?.();
      }
    };

    if (voices && voices.length > 0) {
      startSpeak();
    } else {
      window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.onvoiceschanged = null;
        startSpeak();
      };
      setTimeout(startSpeak, 250);
    }

    return () => {
      window.speechSynthesis.cancel();
      isCurrentlySpeaking = false;
      notifyState(false, null);
    };
  } catch (err) {
    console.warn('Security warning speech exception:', err);
    isCurrentlySpeaking = false;
    notifyState(false, null);
    onEnd?.();
    return () => {};
  }
};
